<?php
  $a = 56;
  $b = 12;
  $c = $a / $b;

  echo $c;
?>
